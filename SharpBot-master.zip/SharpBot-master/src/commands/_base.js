exports.run = function (bot, msg, args) {
    // insert code here
};

exports.info = {
    name: '',
    usage: '',
    description: ''
};
